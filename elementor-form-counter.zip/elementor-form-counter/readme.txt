=== Elementor Form Submission Counter (Unique + Live) ===
Contributors: precious, gpt
Tags: elementor, forms, counter, ajax, shortcode
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Counts unique email submissions per Elementor form, shows a live-updating counter via shortcode, and provides an admin page to reset per-form or all counters.

== Description ==
- Unique email counting per form (case-insensitive)
- Shortcode `[form_counter form="Waitlist"]`
- Live AJAX refresh on `submit_success`
- Admin page: **Settings → Form Counter** (reset per-form or all)
- Uninstall cleans all plugin data

== Installation ==
1. Upload the `elementor-form-counter` folder to `/wp-content/plugins/` or install the ZIP.
2. Activate the plugin via **Plugins**.
3. Place `[form_counter form="Waitlist"]` where you want the counter.
4. Ensure your Elementor form includes an Email field. The plugin will auto-detect it.

== Changelog ==
= 1.1.0 =
* Initial public release.
