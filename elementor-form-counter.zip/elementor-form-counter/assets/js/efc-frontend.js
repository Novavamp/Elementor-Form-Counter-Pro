(function($){
    function refreshAllCounters(){
        $('.efc-counter').each(function(){
            var $el = $(this);
            var slug = $el.data('efc-slug');
            if(!slug){ return; }
            $.post(EFC_Ajax.ajax_url, {
                action: 'efc_get_count',
                slug: slug,
                nonce: EFC_Ajax.nonce
            }, function(resp){
                if(resp && resp.success && resp.data && typeof resp.data.count !== 'undefined'){
                    $el.text(resp.data.count);
                }
            });
        });
    }

    $(document).ready(function(){
        // After a successful Elementor form submission, refresh counters.
        $(document).on('submit_success', function(event, data){
            refreshAllCounters();
        });
    });
})(jQuery);
