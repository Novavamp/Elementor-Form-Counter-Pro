<?php
// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$forms = get_option( 'efc_forms_index', array() );
if ( is_array( $forms ) ) {
    foreach ( $forms as $slug ) {
        delete_option( 'efc_' . $slug . '_count' );
        delete_option( 'efc_' . $slug . '_emails' );
        delete_option( 'efc_label_' . $slug );
    }
}
delete_option( 'efc_forms_index' );
