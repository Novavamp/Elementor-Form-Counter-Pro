<?php
namespace EFC;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Core counter logic: listens to Elementor form submissions,
 * stores unique emails per form (by form_name -> slug), increments a count option.
 */
class Counter {

    public static function init() {
        // Elementor Pro submission hook
        add_action( 'elementor_pro/forms/new_record', [ __CLASS__, 'on_form_submit' ], 10, 2 );
    }

    /**
     * Build a slug from form name (e.g., "Waitlist Form" -> "waitlist-form")
     */
    public static function slug_from_form_name( $form_name ) {
        $slug = sanitize_title( $form_name );
        return $slug ?: 'default';
    }

    /**
     * Option keys per form slug
     */
    public static function opt_emails_key( $slug ) {
        return 'efc_' . $slug . '_emails';
    }
    public static function opt_count_key( $slug ) {
        return 'efc_' . $slug . '_count';
    }

    /**
     * Track encountered forms for the admin UI
     */
    public static function opt_forms_index_key() {
        return 'efc_forms_index';
    }

    /**
     * Handle Elementor form submission
     */
    public static function on_form_submit( $record, $handler ) {
        $form_name = $record->get_form_settings( 'form_name' );
        if ( empty( $form_name ) ) {
            return;
        }

        $slug = self::slug_from_form_name( $form_name );

        // Extract fields: prefer the field with type=email; fallback to id "email"
        $raw_fields = $record->get( 'fields' );
        if ( empty( $raw_fields ) || ! is_array( $raw_fields ) ) {
            return;
        }

        $email = '';
        foreach ( $raw_fields as $fid => $field ) {
            $type  = isset( $field['type'] ) ? $field['type'] : '';
            $value = isset( $field['value'] ) ? $field['value'] : '';
            if ( empty( $email ) && $type === 'email' ) {
                $email = sanitize_email( $value );
            }
        }
        if ( empty( $email ) && isset( $raw_fields['email']['value'] ) ) {
            $email = sanitize_email( $raw_fields['email']['value'] );
        }
        if ( empty( $email ) ) {
            return;
        }

        // Load or init email list
        $emails_key = self::opt_emails_key( $slug );
        $count_key  = self::opt_count_key( $slug );

        $emails = get_option( $emails_key, array() );
        if ( ! is_array( $emails ) ) {
            $emails = array();
        }

        // Normalize email to lowercase to ensure uniqueness
        $email_norm = strtolower( $email );

        if ( ! in_array( $email_norm, $emails, true ) ) {
            $emails[] = $email_norm;
            update_option( $emails_key, $emails, false );

            $count = (int) get_option( $count_key, 0 );
            update_option( $count_key, $count + 1, false );
        }

        // Track this form in the forms index for admin listing
        $forms_index = get_option( self::opt_forms_index_key(), array() );
        if ( ! is_array( $forms_index ) ) {
            $forms_index = array();
        }
        if ( ! in_array( $slug, $forms_index, true ) ) {
            $forms_index[] = $slug;
            update_option( self::opt_forms_index_key(), $forms_index, false );
            // Also store human-readable label for admin
            update_option( 'efc_label_' . $slug, sanitize_text_field( $form_name ), false );
        }
    }
}

Counter::init();
