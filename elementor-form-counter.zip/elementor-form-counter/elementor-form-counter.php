<?php
/**
 * Plugin Name: Elementor Form Submission Counter (Unique + Live)
 * Plugin URI:  https://example.com/
 * Description: Counts unique email submissions per Elementor form, displays via shortcode, live-updates after submit, and includes an admin reset page.
 * Version:     1.1.0
 * Author:      Precious + GPT
 * License:     GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: efc
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'EFC_VERSION', '1.1.0' );
define( 'EFC_PLUGIN_FILE', __FILE__ );
define( 'EFC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'EFC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once EFC_PLUGIN_DIR . 'includes/class-efc-counter.php';
require_once EFC_PLUGIN_DIR . 'includes/class-efc-admin.php';

/**
 * Enqueue frontend script
 */
add_action( 'wp_enqueue_scripts', function() {
    wp_register_script(
        'efc-frontend',
        EFC_PLUGIN_URL . 'assets/js/efc-frontend.js',
        array( 'jquery' ),
        EFC_VERSION,
        true
    );
    wp_localize_script( 'efc-frontend', 'EFC_Ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'efc_nonce' ),
    ) );
    wp_enqueue_script( 'efc-frontend' );
});

/**
 * Shortcode: [form_counter form="Waitlist"]
 * - "form": Elementor Form Name (from the widget settings). Default "Waitlist".
 */
add_shortcode( 'form_counter', function( $atts ) {
    $atts = shortcode_atts( array(
        'form'        => 'Waitlist',
        'empty_label' => '0',
    ), $atts, 'form_counter' );

    $form_name = sanitize_text_field( $atts['form'] );
    $slug      = \EFC\Counter::slug_from_form_name( $form_name );
    $count     = (int) get_option( \EFC\Counter::opt_count_key( $slug ), 0 );

    return sprintf(
        '<span class="efc-counter" data-efc-slug="%s">%d</span>',
        esc_attr( $slug ),
        $count
    );
} );

/**
 * AJAX endpoint to fetch count for a slug (used by JS to refresh after submit).
 */
add_action( 'wp_ajax_efc_get_count', function() {
    check_ajax_referer( 'efc_nonce', 'nonce' );
    $slug = isset($_POST['slug']) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
    if ( empty( $slug ) ) {
        wp_send_json_error( array( 'message' => 'Missing slug' ), 400 );
    }
    $count = (int) get_option( \EFC\Counter::opt_count_key( $slug ), 0 );
    wp_send_json_success( array( 'count' => $count ) );
} );
add_action( 'wp_ajax_nopriv_efc_get_count', function() {
    check_ajax_referer( 'efc_nonce', 'nonce' );
    $slug = isset($_POST['slug']) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
    if ( empty( $slug ) ) {
        wp_send_json_error( array( 'message' => 'Missing slug' ), 400 );
    }
    $count = (int) get_option( \EFC\Counter::opt_count_key( $slug ), 0 );
    wp_send_json_success( array( 'count' => $count ) );
} );

/**
 * Uninstall clean-up handled in uninstall.php
 */
