<?php
namespace EFC;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin {

    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'register_menu' ] );
        add_action( 'admin_post_efc_reset', [ __CLASS__, 'handle_reset' ] );
    }

    public static function register_menu() {
        add_options_page(
            __( 'Form Counter', 'efc' ),
            __( 'Form Counter', 'efc' ),
            'manage_options',
            'efc-settings',
            [ __CLASS__, 'render_page' ]
        );
    }

    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $forms = get_option( Counter::opt_forms_index_key(), array() );
        if ( ! is_array( $forms ) ) { $forms = array(); }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Elementor Form Counter', 'efc' ); ?></h1>
            <p><?php esc_html_e( 'Reset counters and unique email lists per form.', 'efc' ); ?></p>

            <?php if ( empty( $forms ) ) : ?>
                <p><?php esc_html_e( 'No forms tracked yet. Submit an Elementor form to appear here.', 'efc' ); ?></p>
            <?php else : ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Form', 'efc' ); ?></th>
                            <th><?php esc_html_e( 'Slug', 'efc' ); ?></th>
                            <th><?php esc_html_e( 'Count', 'efc' ); ?></th>
                            <th><?php esc_html_e( 'Unique Emails', 'efc' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'efc' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $forms as $slug ) :
                        $label = get_option( 'efc_label_' . $slug, $slug );
                        $count = (int) get_option( Counter::opt_count_key( $slug ), 0 );
                        $emails = get_option( Counter::opt_emails_key( $slug ), array() );
                        if ( ! is_array( $emails ) ) { $emails = array(); }
                        $email_count = count( $emails );
                        $reset_url = wp_nonce_url(
                            admin_url( 'admin-post.php?action=efc_reset&slug=' . urlencode( $slug ) ),
                            'efc_reset_' . $slug
                        );
                        ?>
                        <tr>
                            <td><?php echo esc_html( $label ); ?></td>
                            <td><code><?php echo esc_html( $slug ); ?></code></td>
                            <td><?php echo esc_html( $count ); ?></td>
                            <td><?php echo esc_html( $email_count ); ?></td>
                            <td>
                                <a href="<?php echo esc_url( $reset_url ); ?>" class="button button-secondary" onclick="return confirm('Reset this form\\'s count and emails?');">
                                    <?php esc_html_e( 'Reset', 'efc' ); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php
            // Global reset link
            $global_reset_url = wp_nonce_url(
                admin_url( 'admin-post.php?action=efc_reset&slug=__all__' ),
                'efc_reset___all__'
            );
            ?>
            <p>
                <a href="<?php echo esc_url( $global_reset_url ); ?>" class="button button-primary" onclick="return confirm('Reset ALL forms data?');">
                    <?php esc_html_e( 'Reset All', 'efc' ); ?>
                </a>
            </p>
        </div>
        <?php
    }

    public static function handle_reset() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Forbidden', 403 );
        }
        $slug = isset( $_GET['slug'] ) ? sanitize_key( wp_unslash( $_GET['slug'] ) ) : '';
        if ( empty( $slug ) ) {
            wp_safe_redirect( admin_url( 'options-general.php?page=efc-settings' ) );
            exit;
        }

        if ( ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'efc_reset_' . $slug ) ) {
            wp_die( 'Invalid nonce' );
        }

        if ( '__all__' === $slug ) {
            $forms = get_option( Counter::opt_forms_index_key(), array() );
            if ( is_array( $forms ) ) {
                foreach ( $forms as $s ) {
                    delete_option( Counter::opt_count_key( $s ) );
                    delete_option( Counter::opt_emails_key( $s ) );
                    delete_option( 'efc_label_' . $s );
                }
            }
            delete_option( Counter::opt_forms_index_key() );
        } else {
            delete_option( Counter::opt_count_key( $slug ) );
            delete_option( Counter::opt_emails_key( $slug ) );
            delete_option( 'efc_label_' . $slug );

            // Remove slug from index
            $forms = get_option( Counter::opt_forms_index_key(), array() );
            if ( is_array( $forms ) ) {
                $forms = array_values( array_diff( $forms, array( $slug ) ) );
                update_option( Counter::opt_forms_index_key(), $forms );
            }
        }

        wp_safe_redirect( admin_url( 'options-general.php?page=efc-settings&efc=reset-ok' ) );
        exit;
    }
}

Admin::init();
